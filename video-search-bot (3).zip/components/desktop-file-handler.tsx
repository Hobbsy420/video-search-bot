"use client"

import { useEffect } from "react"

interface DesktopFileHandlerProps {
  onFileSelected: (filePath: string) => void
}

export default function DesktopFileHandler({ onFileSelected }: DesktopFileHandlerProps) {
  useEffect(() => {
    // Check if we're in Electron
    if (typeof window !== "undefined" && window.electronAPI) {
      const handleFileSelected = (_event: any, filePath: string) => {
        onFileSelected(filePath)
      }

      window.electronAPI.onFileSelected(handleFileSelected)

      return () => {
        window.electronAPI.removeAllListeners("file-selected")
      }
    }
  }, [onFileSelected])

  return null
}

// Extend Window interface for TypeScript
declare global {
  interface Window {
    electronAPI?: {
      onFileSelected: (callback: (event: any, filePath: string) => void) => void
      removeAllListeners: (channel: string) => void
    }
  }
}
