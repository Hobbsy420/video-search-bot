"use client"

import type React from "react"

import { useState } from "react"
import { Upload, Search, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import VideoPlayer from "@/components/video-player"
import DesktopFileHandler from "@/components/desktop-file-handler"

export default function VideoSearchForm() {
  const [videoFile, setVideoFile] = useState<File | null>(null)
  const [videoPreview, setVideoPreview] = useState<string | null>(null)
  const [similarityThreshold, setSimilarityThreshold] = useState([75])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.type.startsWith("video/")) {
      setVideoFile(file)
      setVideoPreview(URL.createObjectURL(file))
    }
  }

  const clearVideo = () => {
    setVideoFile(null)
    if (videoPreview) {
      URL.revokeObjectURL(videoPreview)
      setVideoPreview(null)
    }
  }

  const handleDesktopFileSelected = (filePath: string) => {
    // Create a File object from the file path for desktop
    fetch(`file://${filePath}`)
      .then((response) => response.blob())
      .then((blob) => {
        const file = new File([blob], filePath.split("/").pop() || "video", { type: "video/mp4" })
        setVideoFile(file)
        setVideoPreview(URL.createObjectURL(blob))
      })
      .catch(console.error)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would implement the actual search functionality
    // This would typically involve sending the video to a backend service
    console.log("Searching for videos similar to:", videoFile?.name)
    console.log("Similarity threshold:", similarityThreshold[0])
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <DesktopFileHandler onFileSelected={handleDesktopFileSelected} />
      <div className="space-y-2">
        <Label htmlFor="video-upload">Upload reference video</Label>
        <div className="flex items-center gap-4">
          <div className="flex-1">
            <Input id="video-upload" type="file" accept="video/*" onChange={handleFileChange} className="hidden" />
            <div
              className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-gray-50 transition-colors ${videoFile ? "border-green-500 bg-green-50" : "border-gray-300"}`}
              onClick={() => document.getElementById("video-upload")?.click()}
            >
              {!videoPreview ? (
                <div className="flex flex-col items-center justify-center space-y-2">
                  <Upload className="h-8 w-8 text-gray-400" />
                  <p className="text-sm text-gray-500">
                    Click to upload or drag and drop
                    <br />
                    <span className="text-xs">MP4, WebM, or MOV up to 100MB</span>
                  </p>
                </div>
              ) : (
                <div className="relative">
                  <VideoPlayer src={videoPreview} />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    className="absolute top-2 right-2 bg-white rounded-full"
                    onClick={(e) => {
                      e.stopPropagation()
                      clearVideo()
                    }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between">
          <Label>Similarity threshold: {similarityThreshold[0]}%</Label>
        </div>
        <Slider
          value={similarityThreshold}
          onValueChange={setSimilarityThreshold}
          min={50}
          max={100}
          step={1}
          className="py-4"
        />
      </div>

      <div className="flex justify-between items-center pt-4">
        <div className="text-sm text-gray-500">{videoFile ? `Selected: ${videoFile.name}` : "No video selected"}</div>
        <Button type="submit" disabled={!videoFile} className="gap-2">
          <Search className="h-4 w-4" />
          Find Similar Videos
        </Button>
      </div>
    </form>
  )
}
