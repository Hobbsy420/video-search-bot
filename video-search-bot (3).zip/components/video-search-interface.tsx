"use client"

import type React from "react"

import { useState } from "react"
import { Upload, Search, X, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function VideoSearchInterface() {
  const [videoFile, setVideoFile] = useState<File | null>(null)
  const [videoPreview, setVideoPreview] = useState<string | null>(null)
  const [similarityThreshold, setSimilarityThreshold] = useState([75])
  const [isSearching, setIsSearching] = useState(false)
  const [showResults, setShowResults] = useState(false)

  // Sample results data
  const sampleResults = [
    {
      id: "1",
      title: "Art Restoration Process - Painting",
      author: "RestorationArtist",
      thumbnail: "/placeholder.svg?height=180&width=320",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
      similarity: 95,
    },
    {
      id: "2",
      title: "Antique Furniture Restoration",
      author: "VintageRestorer",
      thumbnail: "/placeholder.svg?height=180&width=320",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
      similarity: 87,
    },
    {
      id: "3",
      title: "Ceramic Art Restoration Techniques",
      author: "CeramicArtist",
      thumbnail: "/placeholder.svg?height=180&width=320",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
      similarity: 82,
    },
    {
      id: "4",
      title: "Historical Artifact Restoration",
      author: "HistoryRestorer",
      thumbnail: "/placeholder.svg?height=180&width=320",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
      similarity: 78,
    },
  ]

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.type.startsWith("video/")) {
      setVideoFile(file)
      setVideoPreview(URL.createObjectURL(file))
    }
  }

  const clearVideo = () => {
    setVideoFile(null)
    if (videoPreview) {
      URL.revokeObjectURL(videoPreview)
      setVideoPreview(null)
    }
    setShowResults(false)
  }

  const handleSearch = () => {
    setIsSearching(true)

    // Simulate search delay
    setTimeout(() => {
      setIsSearching(false)
      setShowResults(true)
    }, 1500)
  }

  const [selectedVideo, setSelectedVideo] = useState<string | null>(null)

  return (
    <div className="max-w-4xl mx-auto">
      <Tabs defaultValue="upload" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="upload">Upload Video</TabsTrigger>
          <TabsTrigger value="results" disabled={!showResults}>
            Results
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upload">
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-6">
                <div className="space-y-2">
                  <h2 className="text-xl font-semibold">Upload reference video</h2>
                  <p className="text-sm text-gray-500">Upload a video to find similar content</p>

                  <div className="mt-4">
                    <input
                      id="video-upload"
                      type="file"
                      accept="video/*"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                    <div
                      className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-gray-50 transition-colors ${videoFile ? "border-green-500 bg-green-50" : "border-gray-300"}`}
                      onClick={() => document.getElementById("video-upload")?.click()}
                    >
                      {!videoPreview ? (
                        <div className="flex flex-col items-center justify-center space-y-2 py-8">
                          <Upload className="h-10 w-10 text-gray-400" />
                          <p className="text-sm text-gray-500">
                            Click to upload or drag and drop
                            <br />
                            <span className="text-xs">MP4, WebM, or MOV up to 100MB</span>
                          </p>
                        </div>
                      ) : (
                        <div className="relative">
                          <video src={videoPreview} className="w-full aspect-video rounded" controls />
                          <Button
                            type="button"
                            variant="outline"
                            size="icon"
                            className="absolute top-2 right-2 bg-white rounded-full"
                            onClick={(e) => {
                              e.stopPropagation()
                              clearVideo()
                            }}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <h3 className="font-medium">Similarity threshold: {similarityThreshold[0]}%</h3>
                  </div>
                  <Slider
                    value={similarityThreshold}
                    onValueChange={setSimilarityThreshold}
                    min={50}
                    max={100}
                    step={1}
                    className="py-4"
                  />
                  <p className="text-xs text-gray-500">Higher values will return more closely matched results</p>
                </div>

                <Alert variant="default" className="bg-blue-50 text-blue-800 border-blue-200">
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    This demo uses sample data. In a production environment, this would connect to a video analysis API.
                  </AlertDescription>
                </Alert>

                <div className="flex justify-between items-center pt-4">
                  <div className="text-sm text-gray-500">
                    {videoFile ? `Selected: ${videoFile.name}` : "No video selected"}
                  </div>
                  <Button onClick={handleSearch} disabled={!videoFile || isSearching} className="gap-2">
                    {isSearching ? (
                      <>
                        <div className="h-4 w-4 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                        Searching...
                      </>
                    ) : (
                      <>
                        <Search className="h-4 w-4" />
                        Find Similar Videos
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="results">
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">Search Results</h2>
                  <p className="text-sm text-gray-500">Found {sampleResults.length} similar videos</p>
                </div>

                {selectedVideo && (
                  <div className="mb-8">
                    <video src={selectedVideo} className="w-full aspect-video rounded-lg" controls autoPlay />
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {sampleResults.map((video) => (
                    <div
                      key={video.id}
                      className="border rounded-lg overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => setSelectedVideo(video.videoUrl)}
                    >
                      <div className="relative">
                        <img
                          src={video.thumbnail || "/placeholder.svg"}
                          alt={video.title}
                          className="w-full aspect-video object-cover"
                        />
                        <div className="absolute top-2 right-2 bg-green-500 text-white text-xs font-medium px-2 py-1 rounded-full">
                          {video.similarity}% match
                        </div>
                      </div>
                      <div className="p-3">
                        <h3 className="font-medium line-clamp-1">{video.title}</h3>
                        <p className="text-sm text-gray-500">{video.author}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex justify-end">
                  <Button variant="outline" onClick={() => clearVideo()}>
                    New Search
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
