"use client"

import { useState } from "react"
import VideoPlayer from "@/components/video-player"

// Sample data for demonstration
const SAMPLE_VIDEOS = [
  {
    id: "1",
    title: "Art Restoration Process - Painting",
    author: "RestorationArtist",
    thumbnail: "/placeholder.svg?height=180&width=320",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    similarity: 95,
  },
  {
    id: "2",
    title: "Antique Furniture Restoration",
    author: "VintageRestorer",
    thumbnail: "/placeholder.svg?height=180&width=320",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
    similarity: 87,
  },
  {
    id: "3",
    title: "Ceramic Art Restoration Techniques",
    author: "CeramicArtist",
    thumbnail: "/placeholder.svg?height=180&width=320",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
    similarity: 82,
  },
  {
    id: "4",
    title: "Historical Artifact Restoration",
    author: "HistoryRestorer",
    thumbnail: "/placeholder.svg?height=180&width=320",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
    similarity: 78,
  },
]

export default function VideoResults() {
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null)

  return (
    <div className="space-y-6">
      {selectedVideo && (
        <div className="mb-8">
          <div className="max-w-2xl mx-auto">
            <VideoPlayer src={selectedVideo} autoPlay />
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {SAMPLE_VIDEOS.map((video) => (
          <div
            key={video.id}
            className="border rounded-lg overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => setSelectedVideo(video.videoUrl)}
          >
            <div className="relative">
              <img
                src={video.thumbnail || "/placeholder.svg"}
                alt={video.title}
                className="w-full aspect-video object-cover"
              />
              <div className="absolute top-2 right-2 bg-green-500 text-white text-xs font-medium px-2 py-1 rounded-full">
                {video.similarity}% match
              </div>
            </div>
            <div className="p-3">
              <h3 className="font-medium line-clamp-1">{video.title}</h3>
              <p className="text-sm text-gray-500">{video.author}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
